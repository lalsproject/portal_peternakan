<div class="col-md-12">
	<div class="alert alert-info" role="alert">
		<h3><strong>Selamat Datang Di Portal Pemetaan Zonasi Peternakan Di Kota Tomohon</strong></h3>
		<p>Web ini dibuat untuk mempermudah masyarakat untuk mencari peternakan yang ada di Kota Tomohon.<br>
		Pada web ini pengguna dapat mencari lokasi peternakan yang ada di Kota Tomohon.<br>
		Pada web ini terdapat lokasi peternakan ayam, babi, dan sapi</p>
	</div>
</div>				
<div class="col-md-12">
	<div class="card">
		<div class="card-header bg-primary">
			<strong>PETA SEBARAN PETERNAKAN DI KOTA TOMOHON</strong>
		</div>
		<div class="card-body" style="height: 100vh;padding: 0px;">
			<div class="embed-responsive embed-responsive-16by9" style="width: 100%;height: 100%;">
				<iframe class="embed-responsive-item" src="<?= site_url('maps') ?>" allowfullscreen></iframe>
			</div>
		</div>			
	</div>
</div>